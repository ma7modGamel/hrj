# Contents

1. [Overview](#how-to-use-it)
1. [Markup Contents](#markup-contents)

## How to use it?

Run the website from the responsive tab in your browser or resize your window to be less than or equal to **767px** wide, as these modifications should appear only on the mobile and tablet screens.

## Markup Contents

1. **Search Bar**: Where you can find:

   - the main navbar toggler and menu.
   - The search form.
   - the filter by category nav menu toggler.

1. **Top Navbar**: Where you can find links to all the categories.

1. **Filter Bar**: Where you can:

   - Filter listings.
   - Go to map.
   - Change the view grid layout.

1. **Bottom Navbar**
